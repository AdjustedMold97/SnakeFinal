﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Snake_2._0
{
    class Program
    {
        static void Main(string[] args)
        {
            //setting the window size
            Console.WindowHeight = 16;
            Console.WindowWidth = 32;
            int screenwidth = Console.WindowWidth;
            int screenheight = Console.WindowHeight;

            //declaring some variables and creating
            // a RNG object
            Random rand = new Random();
            int score = 5;
            bool gameover = false;
            bool buttonpressed;

            //creating a "Pixel" object
            //hoofd is the snake head
            Pixel headPos = new Pixel();
            headPos.xpos = screenwidth / 2;
            headPos.ypos = screenheight / 2;
            headPos.pcolor = ConsoleColor.Red;

            //start moving right
            string movement = "RIGHT";

            //list of the x and y values the snake
            //is taking up
            List<Pixel> snakePositions = new List<Pixel>();

            //spawns a berry at a random location
            Pixel berry = new Pixel();
            berry.xpos = rand.Next(0, screenwidth);
            berry.ypos = rand.Next(0, screenheight);

            DateTime tijd = DateTime.Now;
            DateTime tijd2 = DateTime.Now;

            while (true)
            {

                //clear the screen to make a new frame
                Console.Clear();

                //end the game if we reach an edge
                if (headPos.xpos == screenwidth - 1 || headPos.xpos == 0 || headPos.ypos == screenheight - 1 || headPos.ypos == 0)
                    gameover = true;

                //these next 4 for loops draw the
                //borders of the screen
                for (int i = 0; i < screenwidth; i++)
                {
                    Console.SetCursorPosition(i, 0);
                    Console.Write("■");
                }

                for (int i = 0; i < screenwidth; i++)
                {
                    Console.SetCursorPosition(i, screenheight - 1);
                    Console.Write("■");
                }

                for (int i = 0; i < screenheight; i++)
                {
                    Console.SetCursorPosition(0, i);
                    Console.Write("■");
                }

                for (int i = 0; i < screenheight; i++)
                {
                    Console.SetCursorPosition(screenwidth - 1, i);
                    Console.Write("■");
                }

                //set color to green to draw snake
                Console.ForegroundColor = ConsoleColor.Green;

                //increment score if we hit a berry
                //spawn a berry at a new random spot
                if (berry.xpos == headPos.xpos && berry.ypos == headPos.ypos)
                {
                    score++;
                    berry.xpos = rand.Next(1, screenwidth - 2);
                    berry.ypos = rand.Next(1, screenheight - 2);
                }

                for (int i = 0; i < snakePositions.Count(); i++)
                {
                    Console.SetCursorPosition(snakePositions[i].xpos, snakePositions[i].ypos);
                    Console.Write("■");

                    //game over if you run into yourself
                    if (snakePositions[i].xpos == headPos.xpos && snakePositions[i].ypos == headPos.ypos)
                        gameover = true;
                }

                //end game
                if (gameover)
                    break;

                //draw the head
                Console.SetCursorPosition(headPos.xpos, headPos.ypos);
                Console.ForegroundColor = headPos.pcolor;
                Console.Write("■");

                //draw the berry
                Console.SetCursorPosition(berry.xpos, berry.ypos);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("■");

                tijd = DateTime.Now;
                buttonpressed = false;

                while (true)
                {
                    tijd2 = DateTime.Now;
                    if (tijd2.Subtract(tijd).TotalMilliseconds > 100) { break; }
                    if (Console.KeyAvailable)
                    {
                        ConsoleKeyInfo toets = Console.ReadKey(true);
                        if (toets.Key.Equals(ConsoleKey.UpArrow) && movement != "DOWN" && !buttonpressed)
                        {
                            movement = "UP";
                            buttonpressed = true;
                        }
                        if (toets.Key.Equals(ConsoleKey.DownArrow) && movement != "UP" && !buttonpressed)
                        {
                            movement = "DOWN";
                            buttonpressed = true;
                        }
                        if (toets.Key.Equals(ConsoleKey.LeftArrow) && movement != "RIGHT" && !buttonpressed)
                        {
                            movement = "LEFT";
                            buttonpressed = true;
                        }
                        if (toets.Key.Equals(ConsoleKey.RightArrow) && movement != "LEFT" && !buttonpressed)
                        {
                            movement = "RIGHT";
                            buttonpressed = true;
                        }
                    }
                }

                snakePositions.Add(new Pixel(headPos.xpos, headPos.ypos));

                switch (movement)
                {
                    case "UP":
                        headPos.ypos--;
                        break;
                    case "DOWN":
                        headPos.ypos++;
                        break;
                    case "LEFT":
                        headPos.xpos--;
                        break;
                    case "RIGHT":
                        headPos.xpos++;
                        break;
                }

                //remove the back of the snake
                if (snakePositions.Count() > score)
                    snakePositions.RemoveAt(0);

            }
            Console.SetCursorPosition(screenwidth / 5, screenheight / 2);
            Console.WriteLine("Game over, Score: " + score);
            Console.SetCursorPosition(screenwidth / 5, screenheight / 2 + 1);
        }

        class Pixel
        {
            public int xpos { get; set; }
            public int ypos { get; set; }
            public ConsoleColor pcolor { get; set; }

            public Pixel(int x, int y)
            {
                xpos = x;
                ypos = y;
            }

            //default constructor
            public Pixel() { }

        }
    }
}